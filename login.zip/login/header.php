<!--
this is header file which is visible in registration and login page.
-->
<?php
include_once('link.php');

?>

<nav class="navbar navbar-default">
	<div class="container-fluid">
		<ul class="nav navbar-nav">
			<li><a href="registration.php">Registration</a></li>
			<li><a href="index.php">Login</a></li>
			<li><a href="https://www.wunderground.com/weather/np/kathmandu">Weather</a></li>
		</ul>
	</div>
</nav>