<?php
include_once('connection.php');
$query="SELECT * FROM field_data;";
$result = mysqli_query($conn,$query);

?>
<!DOCTYPE html>
<html>
<title>
	<head> fetch data from datbase</head>
</title>
<body>
<table align="center" border="1px" style="width:1000px; line-height:80px;">
	<tr>
		<th colspan="4"><h2>Record</h2></th>
	</tr>
	<t>
		<th>Time</th>
		<th>Temp</th>
		<th>Hum</th>
		<th>Moi</th>
	</t>
<?php
	while($row = mysqli_fetch_assoc($result))
		{
?>
		<tr>
			<td><?php echo $row['Time']; ?></td>
			<td><?php echo $row['Temp']; ?></td>
			<td><?php echo $row['Hum']; ?></td>
			<td><?php echo $row['Moi']; ?></td>
		</tr>
		 <?php
		 }
		 ?>
</table>
</body>
</html>