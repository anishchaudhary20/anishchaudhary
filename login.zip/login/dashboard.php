<!--
Into this file, we create a layout for welcome page.
-->

<?php
include_once('link.php');
include_once('header1.php');
require_once('connection.php');

$id = $_SESSION['id'];
$fname = $lname = $email = $gender = '';
$sql = "SELECT * FROM user WHERE ID='$id'";
$result = mysqli_query($conn, $sql);
$sql1 = "SELECT * FROM field_data";
$result1 = mysqli_query($conn, $sql1);
if(mysqli_num_rows($result) > 0)
{
	while($row = mysqli_fetch_assoc($result))
	{
		$fname = $row["Firstname"];
		$lname = $row["Lastname"];
		
	}
	if(mysqli_num_rows($result) > 0)
{
	while($row = mysqli_fetch_assoc($result1))
	{
		$current = $row["Time"];
		$temp = $row["Temp"];
		$humi = $row["Hum"];
		$moi = $row["Moi"];
		$img = $row["Img"];
	}
}
}

?>
<!DOCTYPE html>
<head>
	<body>
	

	
	<div class="jumbotron">
		<center>
			<h1>Welcome <?php echo $fname." ".$lname; ?><br>Smart Irrigation System</h1>
		</center>

	</div>
	<div>
		<table>
			<tr>
				<h2 align='center'>Motor Control</h2>
				<th><button onclick="Motor On"><img src="source.gif" width="300" height="100"></button></th>
					
				<th><button type="button">Motor On</button>
				</th>
				<th><button onclick="Motor On"><img src="source.gif" width="300" height="100"></button></th>
					
				<th><button type="button">Motor off</button>
			</tr>
		</table>
	</div>
	<hr>
	<hr>
	<div>
		<h2 align='center'>Temperature</h2>
		<h3>Last Update:&#128347; <?php echo $current; ?></h3>
		<span style='font-size:100px;'>&#127777;</span>
		<h1> Current temperature: <?php echo $temp;?> &#8451;</h1>
		
	</div>
	<hr>
	<hr>
	<div>
		<section>
			<h2 align="center">Humidity</h2>
			<h3> Last Update:&#128347; <?php echo $current;?></h3>
			<span style='font-size:100px;'>&#127781;</span>
			<h1> Current humidity: <?php echo $humi;?></h1>
		</section>
	</div>
	<hr>
	<hr>
	<div>
		<h2 align='center'>Moisture</h2>
		<h3>Last Update:&#128347; <?php echo $current; ?></h3>
		<span style='font-size:100px;'>&#128166;</span>
		<h1> Current Moisture: <?php echo $moi;?></h1>
		
	</div>
	<hr>
	<hr>
	<div>
		<button onclick="window.location.href = 'welcome.php';" align ='center' padding = '70px'>Check Last 10 update &#127785; &#127780;</button>
	</div>
</body>
</head>